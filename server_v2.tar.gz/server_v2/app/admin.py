from django.contrib import admin
from views import *

admin.site.register(Cinema)
admin.site.register(Movie)
admin.site.register(Show)
# Register your models here.
